import { useState, useEffect } from "react";

export default function BishopDashboard() {
  const [activeTab, setActiveTab] = useState("wydarzenie");

  const [caseOptions, setCaseOptions] = useState([]);
  const [selectedCase, setSelectedCase] = useState("");

  const [parishOptions, setParishOptions] = useState([]);
  const [selectedParish, setSelectedParish] = useState("");

  const [priests, setPriests] = useState([]);
  const [editingPriest, setEditingPriest] = useState(null);

  const [newNotice, setNewNotice] = useState({
    title: "",
    content: "",
    validUntil: "",
  });

  useEffect(() => {
    setCaseOptions([
      "Budowa nowego kościoła",
      "Zmiana proboszcza",
      "Organizacja pielgrzymki",
      "Decyzja finansowa",
    ]);

    setParishOptions([
      "Parafia św. Jana",
      "Parafia Matki Bożej",
      "Parafia św. Pawła",
    ]);

    setPriests([
      { id: 1, name: "ks. Adam Nowak", parish: "Parafia św. Jana" },
      { id: 2, name: "ks. Piotr Kowalski", parish: "Parafia Matki Bożej" },
      { id: 3, name: "ks. Michał Zieliński", parish: "Parafia św. Pawła" },
    ]);
  }, []);

  const tabs = [
    { id: "decyzja", label: "Wydaj decyzję" },
    { id: "wydarzenie", label: "Ustal wydarzenie" },
    { id: "parafia", label: "Edytuj parafię" },
    { id: "synod", label: "Synod diecezjalny" },
    { id: "ogloszenie", label: "Dodaj ogłoszenie" },
    { id: "budzet", label: "Budżet diecezjalny" },
    { id: "ksieza", label: "Księża" },
    { id: "misje", label: "Działalność misyjna" },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case "wydarzenie":
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Ustal wydarzenie</h3>
            <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input className="border rounded p-2" placeholder="Tytuł wydarzenia" />
              <input className="border rounded p-2" placeholder="Godzina" type="time" />
              <input className="border rounded p-2" placeholder="Data" type="date" />
              <input className="border rounded p-2" placeholder="Miejsce" />
              <textarea className="col-span-2 border rounded p-2 min-h-[100px]" placeholder="Opis wydarzenia"></textarea>
              <button className="col-span-2 bg-blue-600 text-white rounded p-2">Zatwierdź</button>
            </form>
          </div>
        );

      case "decyzja":
        return (
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h3 className="text-lg font-semibold mb-4">Wydaj decyzję</h3>
            <div>
              <label className="block mb-2 font-medium">Tytuł sprawy</label>
              <select
                className="w-full border rounded p-2"
                value={selectedCase}
                onChange={(e) => setSelectedCase(e.target.value)}
              >
                <option value="">-- Wybierz sprawę --</option>
                {caseOptions.map((option, index) => (
                  <option key={index} value={option}>{option}</option>
                ))}
              </select>
            </div>
            <textarea className="w-full border rounded p-2 min-h-[100px]" placeholder="Opis sytuacji" />
            <input className="border rounded p-2 w-full" placeholder="Kto zgłasza" />
            <div className="flex space-x-2">
              <button className="bg-green-600 text-white p-2 rounded">Zatwierdź</button>
              <button className="bg-red-600 text-white p-2 rounded">Odrzuć</button>
            </div>
          </div>
        );

      case "parafia":
        return (
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h3 className="text-lg font-semibold mb-4">Edytuj parafię</h3>
            <select
              className="w-full border rounded p-2"
              value={selectedParish}
              onChange={(e) => setSelectedParish(e.target.value)}
            >
              <option value="">-- Wybierz parafię --</option>
              {parishOptions.map((parish, index) => (
                <option key={index} value={parish}>{parish}</option>
              ))}
            </select>
            <textarea className="border rounded p-2 w-full min-h-[100px]" placeholder="Opis parafii" />
            <input className="border rounded p-2 w-full" placeholder="Adres parafii" />
            <button className="bg-blue-600 text-white p-2 rounded">Zapisz zmiany</button>
          </div>
        );

      case "ogloszenie":
        return (
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h3 className="text-lg font-semibold mb-4">Dodaj ogłoszenie</h3>

            <div>
              <label className="block mb-1 font-medium">Tytuł ogłoszenia</label>
              <input
                type="text"
                placeholder="Np. Zebranie Rady Parafialnej"
                className="w-full border rounded p-2"
                value={newNotice.title}
                onChange={(e) =>
                  setNewNotice({ ...newNotice, title: e.target.value })
                }
              />
            </div>

            <div>
              <label className="block mb-1 font-medium">Treść ogłoszenia</label>
              <textarea
                placeholder="Wpisz treść ogłoszenia..."
                className="w-full border rounded p-2 min-h-[100px]"
                value={newNotice.content}
                onChange={(e) =>
                  setNewNotice({ ...newNotice, content: e.target.value })
                }
              ></textarea>
            </div>

            <div>
              <label className="block mb-1 font-medium">Data ważności</label>
              <input
                type="date"
                className="w-full border rounded p-2"
                value={newNotice.validUntil}
                onChange={(e) =>
                  setNewNotice({ ...newNotice, validUntil: e.target.value })
                }
              />
            </div>

            <button className="bg-blue-600 text-white p-2 rounded">Dodaj ogłoszenie</button>
          </div>
        );

      case "ksieza":
        return (
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h3 className="text-lg font-semibold mb-4">Lista Księży</h3>
            <ul className="space-y-2">
              {priests.map(priest => (
                <li
                  key={priest.id}
                  onClick={() => setEditingPriest(priest)}
                  className="cursor-pointer border p-2 rounded bg-gray-50 hover:bg-gray-100"
                >
                  <strong>{priest.name}</strong> – {priest.parish}
                </li>
              ))}
            </ul>

            {editingPriest && (
              <div className="mt-6 border-t pt-4">
                <h4 className="text-md font-semibold mb-2">Edycja księdza</h4>
                <input
                  className="border rounded p-2 w-full mb-2"
                  value={editingPriest.name}
                  onChange={(e) =>
                    setEditingPriest({ ...editingPriest, name: e.target.value })
                  }
                />
                <select
                  className="border rounded p-2 w-full mb-2"
                  value={editingPriest.parish}
                  onChange={(e) =>
                    setEditingPriest({ ...editingPriest, parish: e.target.value })
                  }
                >
                  {parishOptions.map((p, i) => (
                    <option key={i} value={p}>{p}</option>
                  ))}
                </select>
                <button className="bg-blue-600 text-white p-2 rounded mr-2">Zapisz</button>
                <button className="bg-gray-400 text-white p-2 rounded" onClick={() => setEditingPriest(null)}>Anuluj</button>
              </div>
            )}
          </div>
        );

      case "synod":
        return (
          <div className="bg-white rounded-lg shadow p-6 space-y-6">
            <h3 className="text-lg font-semibold mb-4">Zwołanie synodu diecezjalnego</h3>

            <div className="space-y-2">
              <label className="block font-medium">Miejsce synodu</label>
              <input type="text" className="border rounded p-2 w-full" placeholder="Np. Kuria Biskupia w Poznaniu" />

              <label className="block font-medium mt-2">Data synodu</label>
              <input type="date" className="border rounded p-2 w-full" />

              <label className="block font-medium mt-2">Zgłaszający</label>
              <input type="text" className="border rounded p-2 w-full" placeholder="Imię i nazwisko" />

              <button className="bg-blue-600 text-white p-2 rounded mt-4">Zwołaj synod</button>
            </div>

            <div>
              <h4 className="text-md font-semibold mb-2 mt-6">Kalendarium synodów</h4>
              <ul className="space-y-2">
                <li className="border rounded p-2 bg-gray-50">
                  <strong>2024-10-12</strong> – Synod w Kurii Biskupiej
                </li>
                <li className="border rounded p-2 bg-gray-50">
                  <strong>2023-11-05</strong> – Synod w Parafii św. Pawła
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-md font-semibold mb-2 mt-6">Dodaj postanowienie synodalne</h4>
              <textarea className="border rounded p-2 w-full min-h-[100px]" placeholder="Treść postanowienia" />
              <button className="bg-green-600 text-white p-2 rounded mt-2">Dodaj postanowienie</button>
            </div>
          </div>
        );

      case "budzet":
      case "misje":
      default:
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">{tabs.find(t => t.id === activeTab)?.label}</h3>
            <p>zawartość zakładki.</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4 relative">
      <div className="absolute top-4 right-4">
        <button className="bg-red-600 text-white px-4 py-2 rounded">Wyloguj</button>
      </div>

      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-4">Panel Biskupa</h1>
        <div className="flex flex-wrap gap-2">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded ${activeTab === tab.id ? "bg-blue-600 text-white" : "bg-white border"}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div>
        {renderContent()}
      </div>
    </div>
  );
}
