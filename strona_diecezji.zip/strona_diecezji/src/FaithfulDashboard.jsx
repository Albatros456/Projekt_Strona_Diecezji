import { useState } from "react";

export default function FaithfulDashboard() {
  const [activeTab, setActiveTab] = useState("ogloszenia");

  const tabs = [
    { id: "ogloszenia", label: "Ogłoszenia" },
    { id: "parafie", label: "Parafie" },
    { id: "wydarzenia", label: "Wydarzenia" },
    { id: "zgloszenia", label: "Wysyłanie zgłoszeń i wniosków" },
    { id: "duchowienstwo", label: "Duchowieństwo i misje" },
    { id: "synod", label: "Synod" },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case "ogloszenia":
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Ogłoszenia</h3>
            <p>Lista aktualnych ogłoszeń diecezjalnych.</p>
          </div>
        );

      case "parafie":
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Lista parafii</h3>
            <p>Przeglądaj parafie, znajdź kontakt i szczegóły.</p>
          </div>
        );

      case "wydarzenia":
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Wydarzenia</h3>
            <p>Harmonogram wydarzeń i możliwość zapisu na wydarzenia.</p>
          </div>
        );

      case "zgloszenia":
        return (
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h3 className="text-lg font-semibold mb-4">Wysyłanie zgłoszeń i wniosków</h3>
            <input className="border rounded p-2 w-full" placeholder="Tytuł zgłoszenia" />
            <textarea className="border rounded p-2 w-full min-h-[100px]" placeholder="Treść zgłoszenia"></textarea>
            <button className="bg-blue-600 text-white p-2 rounded">Wyślij zgłoszenie</button>
          </div>
        );

      case "duchowienstwo":
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Duchowieństwo i misje</h3>
            <p>Informacje o księżach oraz działalności misyjnej diecezji.</p>
          </div>
        );

      case "synod":
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Postanowienia Synodu</h3>
            <p>Przeglądaj postanowienia synodalne i dokumenty.</p>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4 relative">
      {/* Wyloguj */}
      <div className="absolute top-4 right-4">
        <button className="bg-red-600 text-white px-4 py-2 rounded">Wyloguj</button>
      </div>

      {/* Panel Wiernego */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-4">Panel Wiernego</h1>
        <div className="flex flex-wrap gap-2">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded ${activeTab === tab.id ? "bg-blue-600 text-white" : "bg-white border"}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Treść zakładki */}
      <div>
        {renderContent()}
      </div>
    </div>
  );
}
