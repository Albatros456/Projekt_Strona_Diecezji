import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import BishopDashboard from "./BishopDashboard";
import FaithfulDashboard from "./FaithfulDashboard";
import LoginPage from "./LoginPage";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/biskup" element={<BishopDashboard />} />
        <Route path="/wierny" element={<FaithfulDashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
